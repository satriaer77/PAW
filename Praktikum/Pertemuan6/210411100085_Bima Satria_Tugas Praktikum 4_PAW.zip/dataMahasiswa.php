<?php

$dataMahasiswa  = [
    [
        "nama"   => "Alfia Nurul rdaus",
        "nim"    => "120411100056",
        "alamat" => "Kediri"
    ],
    [
        "nama"   => "Ahmad Fauzi",
        "nim"    => "120411100043",
        "alamat" => "Sumenep"
    ],
    [
        "nama"   => "Sinta Nuraini",
        "nim"    => "120411100087",
        "alamat" => "Bangkalan"
    ],
];

$pengguna = [
    [
        "id_user"  => "U-001",
        "username" => "alexandra",
        "password" => "cfe223808d4354fff7358eaa6d981f3f982c8d5e"
    ],
    [
        "id_user"  => "U-002",
        "username" => "jaka",
        "password" => "46b30b07285d332913a25970522a3ccab0f2d97e"
    ],

];

?>