<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Tugas extends Controller
{
    public function home()
    {
      return view('cobu');
    }
    public function about()
    {
      return view('cobu');
    }
    public function tp()
    {
      return view('cobu');
    }
}
