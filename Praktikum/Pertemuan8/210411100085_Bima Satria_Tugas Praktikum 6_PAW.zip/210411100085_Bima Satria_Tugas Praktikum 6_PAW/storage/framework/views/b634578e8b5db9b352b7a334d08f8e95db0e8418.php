<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTM | <?php echo e($title); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <header> <?php echo $__env->yieldContent('header'); ?> </header>
    <content class="flex flex-row justify-between">
    <div class="left w-80"></div>
    <?php echo $__env->yieldContent('content'); ?> 
    <div class="right w-80"></div>
    </content>
</body>
</html><?php /**PATH /home/bimasatria/Documents/ApacheServer/PAW/Praktikum/Pertemuan8/cobuPraktikum/resources/views/template/main.blade.php ENDPATH**/ ?>